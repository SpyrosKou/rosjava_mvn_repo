/*
 * Copyright 2017 Ekumen, Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.ros.helpers;

import com.google.common.base.Preconditions;
import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.RosLog;
import org.ros.node.parameter.ParameterTree;

import org.yaml.snakeyaml.Yaml;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Loads parameters from Yaml files into the ROS parameter server.
 * A different namespace can be specified for each of the files to load.
 * To use this node, create a {@link Resource} list with the resources to load,
 * and start it in the standard RosJava way.
 *
 * @author lucas@ekumenlabs.com (Lucas Chiesa).
 * Modified by jubeira@ekumenlabs.com (Juan I. Ubeira)
 */
public final class ParameterLoaderNode extends AbstractNodeMain {

    public static final String NODE_NAME = "parameter_loader";
    private final ArrayList<LoadedResource> params = new ArrayList<>();
    private RosLog rosLog = null;

    /**
     * Default constructor
     *
     * @param resources Array of resources with their respective namespace to load.
     */
    public ParameterLoaderNode(final List<Resource> resources) {
        Preconditions.checkNotNull(resources);
        for (final Resource resource : resources) {
            Preconditions.checkNotNull(resource.inputStream);
            this.addSingleYmlInput(resource.inputStream, resource.namespace == null ? "" : resource.namespace);
        }
    }

    private final void addSingleYmlInput(final InputStream ymlInputStream, final String namespace) {
        final Object loadedYaml = new Yaml().load(ymlInputStream);
        if (loadedYaml != null && loadedYaml instanceof Map<?, ?>) {
            this.params.add(new LoadedResource(Map.class.cast(loadedYaml), namespace));
        }
    }

    private final void addParams(final ParameterTree parameterTree, final String namespace, final Map<?, ?> params) {
        for (final Map.Entry<?, ?> e : params.entrySet()) {
            final String fullKeyName = namespace + "/" + e.getKey().toString();
            if (this.rosLog != null && this.rosLog.isDebugEnabled()) {
                this.rosLog.debug("Loading parameter " + fullKeyName + " \nValue = " + e.getValue());
            }
            if (e.getValue() instanceof String) {
                parameterTree.set(fullKeyName, String.class.cast(e.getValue()));
            } else if (e.getValue() instanceof Integer) {
                parameterTree.set(fullKeyName, Integer.class.cast(e.getValue()));
            } else if (e.getValue() instanceof Double) {
                parameterTree.set(fullKeyName, Double.class.cast(e.getValue()));
            } else if (e.getValue() instanceof Map) {
                parameterTree.set(fullKeyName, Map.class.cast(e.getValue()));
            } else if (e.getValue() instanceof Boolean) {
                parameterTree.set(fullKeyName, Boolean.class.cast(e.getValue()));
            } else if (e.getValue() instanceof List) {
                parameterTree.set(fullKeyName, List.class.cast(e.getValue()));
            } else if (this.rosLog != null && this.rosLog.isDebugEnabled()) {
                this.rosLog.debug("Unknown type parameter " + fullKeyName + " is. Value = " + e.getValue());
                this.rosLog.debug("Class name is: " + e.getValue().getClass().getName());
            }
        }
    }

    /**
     * @return the name of the Node that will be used if a name was not
     * specified in the Node's associated NodeConfiguration.
     */
    @Override
    public final GraphName getDefaultNodeName() {
        return GraphName.of(NODE_NAME);
    }

    @Override
    public final void onStart(final ConnectedNode connectedNode) {
        final ParameterTree parameterTree = connectedNode.getParameterTree();
        this.rosLog = connectedNode.getLog();

        // TODO: For some reason, setting the / param when using a rosjava master doesn't work
        // It does work fine with an external master, and also setting other params of any type
        for (final LoadedResource loadedResource : this.params) {
            this.addParams(parameterTree, loadedResource.getNamespace(), loadedResource.getResource());
        }
        connectedNode.shutdown();
    }

}
