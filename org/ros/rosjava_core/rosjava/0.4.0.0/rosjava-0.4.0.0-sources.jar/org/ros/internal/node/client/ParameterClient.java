/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.node.client;

import org.ros.internal.node.server.NodeIdentifier;
import org.ros.internal.node.server.ParameterServer;
import org.ros.internal.node.xmlrpc.ParameterServerXmlRpcEndpoint;
import org.ros.namespace.GraphName;

import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Provide access to the XML-RPC API for a ROS {@link ParameterServer}.
 *
 * @author kwc@willowgarage.com (Ken Conley)
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class ParameterClient extends Client<ParameterServerXmlRpcEndpoint> {

  private final NodeIdentifier nodeIdentifier;
  private final String nodeName;

  /**
   * Create a new {@link ParameterClient} connected to the specified
   * {@link ParameterServer} URI.
   *
   * @param uri
   *          the {@link URI} of the {@link ParameterServer} to connect to
   */
  public ParameterClient(NodeIdentifier nodeIdentifier, URI uri) {
    super(uri, ParameterServerXmlRpcEndpoint.class);
    this.nodeIdentifier = nodeIdentifier;
    this.nodeName = nodeIdentifier.getName().toString();
  }

  public final Response<Object> getParam(GraphName parameterName) {
    return Response.fromListCheckedFailure(xmlRpcEndpoint.getParam(nodeName, parameterName.toString()),
        ObjectResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, Boolean parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, Integer parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, Double parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, String parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, List<?> parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<Void> setParam(GraphName parameterName, Map<?, ?> parameterValue) {
    return Response.fromListChecked(
        xmlRpcEndpoint.setParam(nodeName, parameterName.toString(), parameterValue), VoidResultFactory::applyStatic);
  }

  public final Response<GraphName> searchParam(GraphName parameterName) {
    final Response<String> response =
        Response.fromListCheckedFailure(xmlRpcEndpoint.searchParam(nodeName, parameterName.toString()),
            StringResultFactory::applyStatic);
    return new Response<GraphName>(response.getStatusCode(), response.getStatusMessage(),
        GraphName.of(response.getResult()));
  }

  public final Response<Object> subscribeParam(GraphName parameterName) {
    return Response.fromListChecked(xmlRpcEndpoint.subscribeParam(nodeName, nodeIdentifier.getUri()
        .toString(), parameterName.toString()), ObjectResultFactory::applyStatic);
  }

  public final Response<Integer> unsubscribeParam(GraphName parameterName) {
    return Response.fromListChecked(
        xmlRpcEndpoint.unsubscribeParam(nodeName, nodeIdentifier.getUri().toString(),
            parameterName.toString()), IntegerResultFactory::applyStatic);
  }

  public final Response<Boolean> hasParam(GraphName parameterName) {
    return Response.fromListChecked(xmlRpcEndpoint.hasParam(nodeName, parameterName.toString()),
        BooleanResultFactory::applyStatic);
  }

  public final Response<Void> deleteParam(GraphName parameterName) {
    return Response.fromListChecked(xmlRpcEndpoint.deleteParam(nodeName, parameterName.toString()),
        VoidResultFactory::applyStatic);
  }

  public final Response<Set<GraphName>> getParamNames() {
    final Response<List<String>> response =
        Response.fromListChecked(xmlRpcEndpoint.getParamNames(nodeName), StringListResultFactory::applyStatic);
    final Set<GraphName> graphNames = new HashSet<>();
    for (final String name : response.getResult()) {
      graphNames.add(GraphName.of(name));
    }
    return new Response<>(response.getStatusCode(), response.getStatusMessage(),graphNames);
  }
}
