/*
 * Copyright (C) 2011 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.node.topic;

import com.google.common.base.Preconditions;



import org.ros.concurrent.CancellableLoop;
import org.ros.internal.message.Message;
import org.ros.node.topic.Publisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandles;
import java.util.concurrent.ScheduledExecutorService;

/**
 * Repeatedly send a message out on a given {@link Publisher}.
 * 
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class RepeatingPublisher<T extends Message> {

  private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

  private final Publisher<T> publisher;
  private final T message;
  private final int frequency;
  private final RepeatingPublisherLoop repeatingPublisherLoop;

  /**
   * Executor used to run the {@link RepeatingPublisherLoop}.
   */
  private final ScheduledExecutorService scheduledExecutorService;

  private final class RepeatingPublisherLoop extends CancellableLoop {
    @Override
    public void loop() throws InterruptedException {
      publisher.publish(message);
      if (LOGGER.isInfoEnabled()) {
        LOGGER.info(String.format("Published message %s to publisher %s ", message, publisher));
      }
      Thread.sleep((long) (1000.0d / frequency));
    }
  }

  /**
   * @param publisher
   * @param message
   * @param frequency
   *          the frequency of publication in Hz
   */
  public RepeatingPublisher(final Publisher<T> publisher, T message,final int frequency,
                            final ScheduledExecutorService scheduledExecutorService) {
    this.publisher = publisher;
    this.message = message;
    this.frequency = frequency;
    this.scheduledExecutorService = scheduledExecutorService;
    this.repeatingPublisherLoop = new RepeatingPublisherLoop();
  }

  public void start() {
    Preconditions.checkState(!this.repeatingPublisherLoop.isRunning());
    this.scheduledExecutorService.execute(this.repeatingPublisherLoop);
  }

  public final void cancel() {
    Preconditions.checkState(this.repeatingPublisherLoop.isRunning());
    this.repeatingPublisherLoop.cancel();
  }
}
