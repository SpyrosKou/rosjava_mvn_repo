/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.concurrent;

import com.google.common.base.Preconditions;

import java.util.concurrent.ExecutorService;

/**
 * An interruptable loop that can be run by an {@link ExecutorService}.
 *
 * @author khughes@google.com (Keith M. Hughes)
 */
public abstract class CancellableLoop implements Runnable {

    private final Object mutex = new Object();


    /**
     * {@code true} if the code has been run once, {@code false} otherwise.
     */
    private boolean ranOnce = false;
    private volatile boolean cancelled = false;

    /**
     * The {@link Thread} the code will be running in.
     */
    private Thread thread;


    @Override
    public final void run() {
        synchronized (this.mutex) {
            Preconditions.checkState(!ranOnce, "CancellableLoops cannot be restarted.");
            this.ranOnce = true;
            this.thread = Thread.currentThread();
        }
        try {
            this.setup();
            while (!this.thread.isInterrupted()) {
                if (!this.cancelled) {
                    this.loop();
                }
            }
        } catch (final InterruptedException interruptedException) {
            this.handleInterruptedException(interruptedException);
        } finally {
            this.thread = null;
        }
    }

    /**
     * The setup block for the loop. This will be called exactly once before
     * the first call to {@link #loop()}.
     */
    protected void setup() {
    }

    /**
     * The body of the loop. This will run continuously until the
     * {@link CancellableLoop} has been interrupted externally or by calling
     * {@link #cancel()}.
     */
    protected abstract void loop() throws InterruptedException;

    /**
     * An {@link InterruptedException} was thrown.
     */
    protected void handleInterruptedException(InterruptedException e) {
    }

    /**
     * Interrupts the loop.
     */
    public final void cancel() {
        if (this.thread != null) {
            this.thread.interrupt();
        }
        this.cancelled = true;
    }

    /**
     * @return {@code true} if the loop is running
     */
    public final boolean isRunning() {
        return this.thread != null && !this.thread.isInterrupted() && !this.cancelled;
    }
}
