/*
 * Copyright (C) 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.concurrent;


/**
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class WallTimeRate implements Rate {

    private final long delay;

    private long time;

    public WallTimeRate(int hz) {
        this.delay = 1000 / hz;
        this.time = 0;
    }

    @Override
    public final void sleep() {
        long delta = System.currentTimeMillis() - this.time;
        while (delta < this.delay) {
            try {
                Thread.sleep(this.delay - delta);
            } catch (final InterruptedException e) {
                break;
            }
            delta = System.currentTimeMillis() - this.time;
        }
        this.time = System.currentTimeMillis();
    }
}
