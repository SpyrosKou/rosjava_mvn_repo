/*
 * Copyright (C) 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.node.client;

import com.google.common.collect.Lists;
import org.ros.master.client.TopicType;

import java.util.List;
import java.util.function.Function;

/**
 * A {@link Function<Object,List<TopicType>>} to take an object and turn it into a list of
 * {@link TopicType} instances.
 *
 * @author Keith M. Hughes
 */
final class TopicTypeListResultFactory implements
        Function<Object, List<TopicType>> {

    @Override
    public final List<TopicType> apply(Object value) {
        return applyStatic(value);
    }

    public static final List<TopicType> applyStatic(Object value) {
        final List<TopicType> topics = Lists.newArrayList();

        for (final Object pair : (Object[]) value) {
            topics.add(new TopicType((String) ((Object[]) pair)[0],
                    (String) ((Object[]) pair)[1]));
        }

        return topics;
    }

}
