/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.node.server;

import com.google.common.collect.Lists;
import org.ros.address.AdvertiseAddress;
import org.ros.address.BindAddress;
import org.ros.internal.node.client.MasterClient;
import org.ros.internal.node.parameter.ParameterManager;
import org.ros.internal.node.service.ServiceManager;
import org.ros.internal.node.topic.*;
import org.ros.internal.node.xmlrpc.SlaveXmlRpcEndpointImpl;
import org.ros.internal.transport.ProtocolDescription;
import org.ros.internal.transport.ProtocolNames;
import org.ros.internal.transport.tcp.TcpRosServer;
import org.ros.namespace.GraphName;
import org.ros.node.Node;

import java.net.URI;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class SlaveServer extends XmlRpcServer {

    private final GraphName nodeName;
    private final MasterClient masterClient;
    private final TopicParticipantManager topicParticipantManager;
    private final ParameterManager parameterManager;
    private final TcpRosServer tcpRosServer;
    private final Node node;
    private final AtomicBoolean shutdownStarted;

    public SlaveServer(GraphName nodeName, BindAddress tcpRosBindAddress, AdvertiseAddress tcpRosAdvertiseAddress, BindAddress xmlRpcBindAddress, AdvertiseAddress xmlRpcAdvertiseAddress, MasterClient master, TopicParticipantManager topicParticipantManager, ServiceManager serviceManager, ParameterManager parameterManager, ExecutorService executorService, Node node) {
        super(xmlRpcBindAddress, xmlRpcAdvertiseAddress);
        this.nodeName = nodeName;
        this.masterClient = master;
        this.topicParticipantManager = topicParticipantManager;
        this.parameterManager = parameterManager;
        this.tcpRosServer = new TcpRosServer(tcpRosBindAddress, tcpRosAdvertiseAddress, topicParticipantManager, serviceManager, executorService);
        this.node = node;
        this.shutdownStarted = new AtomicBoolean(false);
    }

    public AdvertiseAddress getTcpRosAdvertiseAddress() {
        return tcpRosServer.getAdvertiseAddress();
    }

    /**
     * Start the XML-RPC server. This start() routine requires that the
     * {@link TcpRosServer} is initialized first so that the slave server returns
     * correct information when topics are requested.
     */
    public final void start() {
        super.start(new SlaveXmlRpcEndpointImpl(this));
        this.tcpRosServer.start();
    }


    @Override
    public final void shutdown() {
        // prevent recursive call of this method
        if (this.shutdownStarted.compareAndSet(false, true)) {
            this.shutdownStarted.set(true);
            this.superShutdown();
            this.tcpRosServer.shutdown();
            if (this.node != null) {
                this.node.shutdown();
            }
            this.shutdownFinalization();
        }
    }

    public List<Object> getBusStats(String callerId) {
        throw new UnsupportedOperationException();
    }

    public List<Object> getBusInfo(String callerId) {
        final List<Object> busInfo = Lists.newArrayList();
        // The connection ID field is opaque to the user. A monotonically increasing
        // integer for now is sufficient.
        int id = 0;
        for (final DefaultPublisher<?> publisher : getPublications()) {
            for (final SubscriberIdentifier subscriberIdentifier : topicParticipantManager.getPublisherConnections(publisher)) {
                final List<String> publisherBusInfo = Lists.newArrayList();
                publisherBusInfo.add(Integer.toString(id));
                publisherBusInfo.add(subscriberIdentifier.getNodeIdentifier().getName().toString());
                // TODO(damonkohler): Pull out BusInfo constants.
                publisherBusInfo.add("o");
                // TODO(damonkohler): Add getter for protocol to topic participants.
                publisherBusInfo.add(ProtocolNames.TCPROS);
                publisherBusInfo.add(publisher.getTopicName().toString());
                busInfo.add(publisherBusInfo);
                id++;
            }
        }
        for (final DefaultSubscriber<?> subscriber : getSubscriptions()) {
            for (final PublisherIdentifier publisherIdentifier : topicParticipantManager.getSubscriberConnections(subscriber)) {
                final List<String> subscriberBusInfo = Lists.newArrayList();
                subscriberBusInfo.add(Integer.toString(id));
                // Subscriber connection PublisherIdentifiers are populated with node
                // URIs instead of names. As a result, the only identifier information
                // available is the URI.
                subscriberBusInfo.add(publisherIdentifier.getNodeIdentifier().getUri().toString());
                // TODO(damonkohler): Pull out BusInfo constants.
                subscriberBusInfo.add("i");
                // TODO(damonkohler): Add getter for protocol to topic participants.
                subscriberBusInfo.add(ProtocolNames.TCPROS);
                subscriberBusInfo.add(publisherIdentifier.getTopicName().toString());
                busInfo.add(subscriberBusInfo);
                id++;
            }
        }
        return busInfo;
    }

    public URI getMasterUri() {
        return masterClient.getRemoteUri();
    }


    public final List<DefaultSubscriber<?>> getSubscriptions() {
        return topicParticipantManager.getSubscribers();
    }

    public final List<DefaultPublisher<?>> getPublications() {
        return topicParticipantManager.getPublishers();
    }

    /**
     * @param parameterName
     * @param parameterValue
     * @return the number of parameter subscribers that received the update
     */
    public final int paramUpdate(GraphName parameterName, Object parameterValue) {
        return parameterManager.updateParameter(parameterName, parameterValue);
    }

    public final void publisherUpdate(String callerId, String topicName, Collection<URI> publisherUris) {
        final GraphName graphName = GraphName.of(topicName);
        if (topicParticipantManager.hasSubscriber(graphName)) {
            final DefaultSubscriber<?> subscriber = topicParticipantManager.getSubscriber(graphName);
            final TopicDeclaration topicDeclaration = subscriber.getTopicDeclaration();
            final Set<PublisherIdentifier> identifiers = PublisherIdentifier.newCollectionFromUris(publisherUris, topicDeclaration);
            subscriber.updatePublishers(identifiers);
        }
    }

    public ProtocolDescription requestTopic(String topicName, Collection<String> protocols) throws ServerException {
        // TODO(damonkohler): Use NameResolver.
        // Canonicalize topic name.
        final GraphName graphName = GraphName.of(topicName).toGlobal();
        if (!topicParticipantManager.hasPublisher(graphName)) {
            throw new ServerException("No publishers for topic: " + graphName);
        }
        for (final String protocol : protocols) {
            if (protocol.equals(ProtocolNames.TCPROS)) {
                try {
                    return ProtocolDescription.createTcpRosProtocolDescription(tcpRosServer.getAdvertiseAddress());
                } catch (Exception e) {
                    throw new ServerException(e);
                }
            }
        }
        throw new ServerException("No supported protocols specified.");
    }

    /**
     * @return a {@link NodeIdentifier} for this {@link SlaveServer}
     */
    public NodeIdentifier toNodeIdentifier() {
        return new NodeIdentifier(nodeName, getUri());
    }
}
