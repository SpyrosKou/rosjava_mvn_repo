/*
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.node.client;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.ros.internal.node.server.NodeIdentifier;
import org.ros.internal.node.server.SlaveServer;
import org.ros.internal.node.server.master.MasterServer;
import org.ros.internal.node.topic.PublisherDeclaration;
import org.ros.internal.node.topic.PublisherIdentifier;
import org.ros.internal.node.topic.TopicDeclaration;
import org.ros.internal.node.xmlrpc.MasterXmlRpcEndpoint;
import org.ros.master.client.SystemState;
import org.ros.master.client.TopicSystemState;
import org.ros.master.client.TopicType;
import org.ros.namespace.GraphName;
import org.ros.node.service.ServiceServer;
import org.ros.node.topic.Publisher;
import org.ros.node.topic.Subscriber;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandles;
import java.net.URI;
import java.util.List;
import java.util.StringJoiner;

/**
 * Provides access to the XML-RPC API exposed by a {@link MasterServer}.
 *
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class MasterClient extends Client<MasterXmlRpcEndpoint> {
    private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    /**
     * Create a new {@link MasterClient} connected to the specified
     * {@link MasterServer} URI.
     *
     * @param uri the {@link URI} of the {@link MasterServer} to connect to
     */
    public MasterClient(final URI uri) {
        super(uri, MasterXmlRpcEndpoint.class);
    }

    /**
     * Registers the given {@link ServiceServer}.
     *
     * @param slave   the {@link NodeIdentifier} where the {@link ServiceServer} is
     *                running
     * @param service the {@link ServiceServer} to register
     * @return a void {@link Response}
     */
    public final Response<Void> registerService(NodeIdentifier slave, ServiceServer<?, ?> service) {
        return Response.fromListChecked(xmlRpcEndpoint.registerService(slave.getName().toString(),
                        service.getName().toString(), service.getUri().toString(), slave.getUri().toString()),
                VoidResultFactory::applyStatic);
    }

    /**
     * Unregisters the specified {@link ServiceServer}.
     *
     * @param slave   the {@link NodeIdentifier} where the {@link ServiceServer} is
     *                running
     * @param service the {@link ServiceServer} to unregister
     * @return the number of unregistered services
     */
    public final Response<Integer> unregisterService(NodeIdentifier slave, ServiceServer<?, ?> service) {
        return Response.fromListChecked(xmlRpcEndpoint.unregisterService(
                        slave.getName().toString(), service.getName().toString(), service.getUri().toString()),
                IntegerResultFactory::applyStatic);
    }

    /**
     * Registers the given {@link Subscriber}. In addition to receiving a list of
     * current {@link Publisher}s, the {@link Subscriber}s {@link SlaveServer}
     * will also receive notifications of new {@link Publisher}s via the
     * publisherUpdate API.
     *
     * @param slave      the {@link NodeIdentifier} that the {@link Subscriber} is running
     *                   on
     * @param subscriber the {@link Subscriber} to register
     * @return a {@link List} or {@link SlaveServer} XML-RPC API URIs for nodes
     * currently publishing the specified topic
     */
    public final Response<List<URI>> registerSubscriber(NodeIdentifier slave, Subscriber<?> subscriber) {
        return Response.fromListChecked(xmlRpcEndpoint.registerSubscriber(slave.getName()
                .toString(), subscriber.getTopicName().toString(), subscriber.getTopicMessageType(), slave
                .getUri().toString()), UriListResultFactory::applyStatic);
    }

    /**
     * Unregisters the specified {@link Subscriber}.
     *
     * @param slave      the {@link NodeIdentifier} where the subscriber is running
     * @param subscriber the {@link Subscriber} to unregister
     * @return the number of unregistered {@link Subscriber}s
     */
    public final Response<Integer> unregisterSubscriber(NodeIdentifier slave, Subscriber<?> subscriber) {
        return Response.fromListChecked(xmlRpcEndpoint.unregisterSubscriber(slave.getName()
                        .toString(), subscriber.getTopicName().toString(), slave.getUri().toString()),
                IntegerResultFactory::applyStatic);
    }

    /**
     * Registers the specified {@link PublisherDeclaration}.
     *
     * @param publisherDeclaration the {@link PublisherDeclaration} of the {@link Publisher} to
     *                             register
     * @return a {@link List} of the current {@link SlaveServer} URIs which have
     * {@link Subscriber}s for the published {@link TopicSystemState}
     */
    public final Response<List<URI>> registerPublisher(final PublisherDeclaration publisherDeclaration) {
        try {
            final String slaveName = publisherDeclaration.getSlaveName().toString();
            final String slaveUri = publisherDeclaration.getSlaveUri().toString();
            final String topicName = publisherDeclaration.getTopicName().toString();
            final String messageType = publisherDeclaration.getTopicMessageType();

            final List<Object> publishers = this.xmlRpcEndpoint.registerPublisher(slaveName, topicName, messageType, slaveUri);
            final Response<List<URI>> response = Response.fromListChecked(publishers, UriListResultFactory::applyStatic);
            return response;
        } catch (final Exception exception) {
            final StringJoiner stringJoiner = new StringJoiner(",");
            try {
                {
                    final String slaveName = publisherDeclaration.getSlaveName().toString();
                    stringJoiner.add("slaveName:" + slaveName);

                }
                {
                    final String slaveUri = publisherDeclaration.getSlaveUri().toString();
                    stringJoiner.add("slaveUri:" + slaveUri);

                }
                {
                    final String topicName = publisherDeclaration.getTopicName().toString();
                    stringJoiner.add("topicName:" + topicName);

                }
                {
                    final String messageType = publisherDeclaration.getTopicMessageType();
                    stringJoiner.add("messageType:" + messageType);

                }
            } catch (final Exception silentException) {

            }
            final RuntimeException runtimeException = new RuntimeException(stringJoiner.toString(),exception);
            LOGGER.error(ExceptionUtils.getStackTrace(runtimeException));
            throw runtimeException;
        }

    }

    /**
     * Unregisters the specified {@link PublisherDeclaration}.
     *
     * @param publisherIdentifier the {@link PublisherIdentifier} of the {@link Publisher} to
     *                            unregister
     * @return the number of unregistered {@link Publisher}s
     */
    public final Response<Integer> unregisterPublisher(PublisherIdentifier publisherIdentifier) {
        String slaveName = publisherIdentifier.getNodeName().toString();
        String slaveUri = publisherIdentifier.getNodeUri().toString();
        String topicName = publisherIdentifier.getTopicName().toString();
        return Response.fromListChecked(
                xmlRpcEndpoint.unregisterPublisher(slaveName, topicName, slaveUri),
                IntegerResultFactory::applyStatic);
    }

    /**
     * @param slaveName the {@link GraphName} of the caller
     * @param nodeName  the name of the {@link SlaveServer} to lookup
     * @return the {@link URI} of the {@link SlaveServer} with the given name
     */
    public final Response<URI> lookupNode(GraphName slaveName, String nodeName) {
        return Response.fromListChecked(xmlRpcEndpoint.lookupNode(slaveName.toString(), nodeName),
                UriResultFactory::applyStatic);
    }

    /**
     * @param slaveName the {@link NodeIdentifier} of the caller
     * @return the {@link URI} of the {@link MasterServer}
     */
    public final Response<URI> getUri(GraphName slaveName) {
        return Response.fromListChecked(xmlRpcEndpoint.getUri(slaveName.toString()),
                UriResultFactory::applyStatic);
    }

    /**
     * @param callerName  the {@link GraphName} of the caller
     * @param serviceName the name of the {@link ServiceServer} to look up
     * @return the {@link URI} of the {@link ServiceServer} with the given name.
     * {@link ServiceServer} as a result
     */
    public final Response<URI> lookupService(GraphName callerName, String serviceName) {
        return Response.fromListCheckedFailure(
                xmlRpcEndpoint.lookupService(callerName.toString(), serviceName), UriResultFactory::applyStatic);
    }

    /**
     * @param callerName the {@link GraphName} of the caller
     * @param subgraph   the subgraph of the topics
     * @return the list of published {@link TopicDeclaration}s
     */
    public final Response<List<TopicDeclaration>> getPublishedTopics(GraphName callerName, String subgraph) {
        return Response.fromListChecked(
                xmlRpcEndpoint.getPublishedTopics(callerName.toString(), subgraph),
                TopicListResultFactory::applyStatic);
    }

    /**
     * Get a {@link List} of all {@link TopicSystemState} message types.
     *
     * @param callerName the {@link GraphName} of the caller
     * @return a {@link List} of {@link TopicType}s
     */
    public final Response<List<TopicType>> getTopicTypes(GraphName callerName) {
        return Response.fromListChecked(xmlRpcEndpoint.getTopicTypes(callerName.toString()),
                TopicTypeListResultFactory::applyStatic);
    }

    /**
     * @param callerName the {@link GraphName} of the caller
     * @return the current {@link SystemState}
     */
    public final Response<SystemState> getSystemState(GraphName callerName) {
        return Response.fromListChecked(xmlRpcEndpoint.getSystemState(callerName.toString()),
                SystemStateResultFactory::applyStatic);
    }
}
