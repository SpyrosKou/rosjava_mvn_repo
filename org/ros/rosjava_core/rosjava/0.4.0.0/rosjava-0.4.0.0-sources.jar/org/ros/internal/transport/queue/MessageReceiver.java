/*
 * Copyright (C) 2012 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.internal.transport.queue;

import org.jboss.netty.buffer.ChannelBuffer;
import org.jboss.netty.channel.ChannelHandlerContext;
import org.jboss.netty.channel.MessageEvent;
import org.ros.concurrent.CircularBlockingDeque;
import org.ros.internal.transport.tcp.AbstractNamedChannelHandler;
import org.ros.message.MessageDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.invoke.MethodHandles;

/**
 * @param <T> the message type
 *
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class MessageReceiver<T> extends AbstractNamedChannelHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(MethodHandles.lookup().lookupClass());

    private final CircularBlockingDeque<LazyMessage<T>> lazyMessages;
    private final MessageDeserializer<T> deserializer;

    public MessageReceiver(CircularBlockingDeque<LazyMessage<T>> lazyMessages,
                           MessageDeserializer<T> deserializer) {
        this.lazyMessages = lazyMessages;
        this.deserializer = deserializer;
    }

    @Override
    public final String getName() {
        return "IncomingMessageQueueChannelHandler";
    }

    @Override
    public final void messageReceived(ChannelHandlerContext ctx, MessageEvent messageEvent) throws Exception {
        final ChannelBuffer buffer = (ChannelBuffer) messageEvent.getMessage();
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug(String.format("Received %d byte message.", buffer.readableBytes()));
        }
        // We have to make a defensive copy of the buffer here because Netty does
        // not guarantee that the returned ChannelBuffer will not be reused.
        lazyMessages.addLast(new LazyMessage<T>(buffer.copy(), deserializer));
        super.messageReceived(ctx, messageEvent);
    }
}