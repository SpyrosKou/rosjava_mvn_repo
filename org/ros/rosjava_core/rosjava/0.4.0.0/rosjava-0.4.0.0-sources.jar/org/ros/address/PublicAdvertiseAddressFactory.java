/*
 * Copyright (C) 2011 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package org.ros.address;

import com.google.common.base.Preconditions;

/**
 * An {@link AdvertiseAddressFactory} which creates public (non-loopback) addresses.
 * 
 * @author damonkohler@google.com (Damon Kohler)
 */
public final class PublicAdvertiseAddressFactory implements AdvertiseAddressFactory {

  private final String host;

  /**
   * Best effort method, returns a new {@link AdvertiseAddress} where the host
   *     is determined automatically.
   *
   *     @return a suitable {@link AdvertiseAddress} for a publicly accessible
   *             {@link BindAddress}
   */
  public PublicAdvertiseAddressFactory() {
    this(InetAddressFactory.newNonLoopback().getCanonicalHostName());
  }

  /**
   * Used defined host
   * @param host
   */
  public PublicAdvertiseAddressFactory(final String host) {
    Preconditions.checkNotNull(host);
    this.host = host;
  }


  @Override
  public final AdvertiseAddress newDefault() {
    return new AdvertiseAddress(host);
  }
}
